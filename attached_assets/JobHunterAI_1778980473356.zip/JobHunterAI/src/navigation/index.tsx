import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";
import { Ionicons } from "@expo/vector-icons";
import { theme } from "../theme";

import DashboardScreen from "../screens/DashboardScreen";
import ApplicationsScreen from "../screens/ApplicationsScreen";
import AddApplicationScreen from "../screens/AddApplicationScreen";
import AIWriterScreen from "../screens/AIWriterScreen";
import AlertsScreen from "../screens/AlertsScreen";
import SettingsScreen from "../screens/SettingsScreen";

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function ApplicationsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ApplicationsList" component={ApplicationsScreen} />
      <Stack.Screen name="AddApplication" component={AddApplicationScreen} />
      <Stack.Screen name="ApplicationDetail" component={AddApplicationScreen} />
    </Stack.Navigator>
  );
}

function DashboardStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="DashboardMain" component={DashboardScreen} />
      <Stack.Screen name="AddApplication" component={AddApplicationScreen} />
      <Stack.Screen name="ApplicationDetail" component={AddApplicationScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="Alerts" component={AlertsScreen} />
    </Stack.Navigator>
  );
}

export default function Navigation() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarStyle: {
            backgroundColor: theme.colors.bg.secondary,
            borderTopColor: theme.colors.bg.border,
            borderTopWidth: 1,
            height: 80,
            paddingBottom: 20,
          },
          tabBarActiveTintColor: theme.colors.accent.cyan,
          tabBarInactiveTintColor: theme.colors.text.muted,
          tabBarLabelStyle: {
            fontSize: theme.font.sizes.xs,
            fontWeight: theme.font.weights.medium,
          },
          tabBarIcon: ({ focused, color, size }) => {
            const icons: Record<string, string> = {
              Dashboard: focused ? "home" : "home-outline",
              Applications: focused ? "briefcase" : "briefcase-outline",
              "AI Writer": focused ? "sparkles" : "sparkles-outline",
              Alerts: focused ? "notifications" : "notifications-outline",
              Settings: focused ? "settings" : "settings-outline",
            };
            return <Ionicons name={(icons[route.name] || "ellipse") as any} size={size} color={color} />;
          },
        })}
      >
        <Tab.Screen name="Dashboard" component={DashboardStack} />
        <Tab.Screen name="Applications" component={ApplicationsStack} />
        <Tab.Screen name="AI Writer" component={AIWriterScreen} />
        <Tab.Screen name="Alerts" component={AlertsScreen} />
        <Tab.Screen name="Settings" component={SettingsScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
