import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Share,
  Alert,
  Clipboard,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { aiService } from "../services/claude";
import { theme } from "../theme";

type WritingMode = "email" | "cover_letter" | "cv_tailor" | "interview_prep" | "follow_up";

const MODES: { key: WritingMode; label: string; icon: string; description: string }[] = [
  { key: "email", label: "Application Email", icon: "mail-outline", description: "Write a job application email" },
  { key: "cover_letter", label: "Cover Letter", icon: "document-text-outline", description: "Generate a full cover letter" },
  { key: "cv_tailor", label: "Tailor CV", icon: "person-outline", description: "Get CV bullet points for any role" },
  { key: "interview_prep", label: "Interview Prep", icon: "mic-outline", description: "Questions & answers for interviews" },
  { key: "follow_up", label: "Follow-Up Email", icon: "refresh-outline", description: "Follow up on an application" },
];

export default function AIWriterScreen() {
  const [mode, setMode] = useState<WritingMode>("email");
  const [company, setCompany] = useState("");
  const [role, setRole] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [daysSince, setDaysSince] = useState("7");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    if (!company && mode !== "cv_tailor") {
      Alert.alert("Missing info", "Please enter the company name");
      return;
    }
    if (!jobDescription && mode !== "follow_up") {
      Alert.alert("Missing info", "Please paste the job description");
      return;
    }

    setLoading(true);
    setResult("");

    try {
      let output = "";
      switch (mode) {
        case "email":
          output = await aiService.generateApplicationEmail(role, company, jobDescription);
          break;
        case "cover_letter":
          output = await aiService.generateCoverLetter(role, company, jobDescription);
          break;
        case "cv_tailor":
          output = await aiService.tailorCVPoints(jobDescription);
          break;
        case "interview_prep":
          output = await aiService.generateInterviewPrep(role, company, jobDescription);
          break;
        case "follow_up":
          output = await aiService.generateFollowUp(company, role, parseInt(daysSince) || 7);
          break;
      }
      setResult(output);
    } catch (err: any) {
      Alert.alert("Error", err.message || "Failed to generate content. Check your API key.");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    Clipboard.setString(result);
    Alert.alert("Copied!", "Content copied to clipboard");
  };

  const shareResult = () => {
    Share.share({ message: result });
  };

  const currentMode = MODES.find((m) => m.key === mode)!;

  return (
    <ScrollView style={styles.container} keyboardShouldPersistTaps="handled">
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>AI Writer</Text>
        <Text style={styles.subtitle}>Powered by Claude AI</Text>
      </View>

      {/* Mode Selector */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.modeScroll}
        contentContainerStyle={styles.modeContainer}
      >
        {MODES.map((m) => (
          <TouchableOpacity
            key={m.key}
            style={[styles.modeChip, mode === m.key && styles.modeChipActive]}
            onPress={() => { setMode(m.key); setResult(""); }}
          >
            <Ionicons
              name={m.icon as any}
              size={14}
              color={mode === m.key ? theme.colors.bg.primary : theme.colors.text.secondary}
            />
            <Text style={[styles.modeChipText, mode === m.key && styles.modeChipTextActive]}>
              {m.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Mode description */}
      <View style={styles.modeInfo}>
        <Ionicons name={currentMode.icon as any} size={20} color={theme.colors.accent.cyan} />
        <Text style={styles.modeDescription}>{currentMode.description}</Text>
      </View>

      {/* Inputs */}
      <View style={styles.form}>
        {mode !== "cv_tailor" && (
          <>
            <InputField
              label="Company"
              placeholder="e.g. Amiran Kenya Ltd"
              value={company}
              onChange={setCompany}
            />
            <InputField
              label="Job Title"
              placeholder="e.g. Cereal Agronomist"
              value={role}
              onChange={setRole}
            />
          </>
        )}

        {mode === "follow_up" && (
          <InputField
            label="Days Since Application"
            placeholder="7"
            value={daysSince}
            onChange={setDaysSince}
            keyboardType="numeric"
          />
        )}

        {mode !== "follow_up" && (
          <View style={styles.field}>
            <Text style={styles.label}>
              {mode === "cv_tailor" ? "Job Description (paste full JD)" : "Job Description"}
            </Text>
            <TextInput
              style={[styles.input, styles.textarea]}
              placeholder="Paste the full job description here..."
              placeholderTextColor={theme.colors.text.muted}
              value={jobDescription}
              onChangeText={setJobDescription}
              multiline
              numberOfLines={6}
              textAlignVertical="top"
            />
          </View>
        )}

        <TouchableOpacity
          style={[styles.generateBtn, loading && styles.generateBtnDisabled]}
          onPress={generate}
          disabled={loading}
        >
          {loading ? (
            <>
              <ActivityIndicator color={theme.colors.bg.primary} size="small" />
              <Text style={styles.generateBtnText}>Generating...</Text>
            </>
          ) : (
            <>
              <Ionicons name="sparkles" size={18} color={theme.colors.bg.primary} />
              <Text style={styles.generateBtnText}>Generate with AI</Text>
            </>
          )}
        </TouchableOpacity>
      </View>

      {/* Result */}
      {result ? (
        <View style={styles.resultContainer}>
          <View style={styles.resultHeader}>
            <Text style={styles.resultTitle}>Generated Content</Text>
            <View style={styles.resultActions}>
              <TouchableOpacity style={styles.actionBtn} onPress={copyToClipboard}>
                <Ionicons name="copy-outline" size={18} color={theme.colors.accent.cyan} />
                <Text style={styles.actionBtnText}>Copy</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionBtn} onPress={shareResult}>
                <Ionicons name="share-outline" size={18} color={theme.colors.accent.cyan} />
                <Text style={styles.actionBtnText}>Share</Text>
              </TouchableOpacity>
            </View>
          </View>
          <Text style={styles.resultText}>{result}</Text>
          <TouchableOpacity style={styles.regenerateBtn} onPress={generate}>
            <Ionicons name="refresh" size={16} color={theme.colors.text.secondary} />
            <Text style={styles.regenerateBtnText}>Regenerate</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

function InputField({ label, placeholder, value, onChange, keyboardType = "default" }: any) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        placeholder={placeholder}
        placeholderTextColor={theme.colors.text.muted}
        value={value}
        onChangeText={onChange}
        keyboardType={keyboardType}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bg.primary },
  header: { paddingHorizontal: theme.spacing.md, paddingTop: 60, paddingBottom: theme.spacing.md },
  title: { fontSize: theme.font.sizes.xxxl, fontWeight: theme.font.weights.bold, color: theme.colors.text.primary },
  subtitle: { color: theme.colors.accent.cyan, fontSize: theme.font.sizes.sm, marginTop: 4 },
  modeScroll: { marginBottom: theme.spacing.md },
  modeContainer: { paddingHorizontal: theme.spacing.md, gap: theme.spacing.sm },
  modeChip: {
    flexDirection: "row", alignItems: "center", gap: 6,
    paddingHorizontal: theme.spacing.md, paddingVertical: theme.spacing.sm,
    borderRadius: theme.radius.full,
    backgroundColor: theme.colors.bg.card,
    borderWidth: 1, borderColor: theme.colors.bg.border,
  },
  modeChipActive: { backgroundColor: theme.colors.accent.cyan, borderColor: theme.colors.accent.cyan },
  modeChipText: { color: theme.colors.text.secondary, fontSize: theme.font.sizes.sm, fontWeight: theme.font.weights.medium },
  modeChipTextActive: { color: theme.colors.bg.primary },
  modeInfo: {
    flexDirection: "row", alignItems: "center", gap: theme.spacing.sm,
    marginHorizontal: theme.spacing.md, marginBottom: theme.spacing.md,
    backgroundColor: theme.colors.accent.cyanDim,
    borderRadius: theme.radius.md, padding: theme.spacing.sm,
  },
  modeDescription: { color: theme.colors.accent.cyan, fontSize: theme.font.sizes.sm },
  form: { paddingHorizontal: theme.spacing.md, gap: theme.spacing.md },
  field: { gap: theme.spacing.xs },
  label: { color: theme.colors.text.secondary, fontSize: theme.font.sizes.sm, fontWeight: theme.font.weights.medium },
  input: {
    backgroundColor: theme.colors.bg.card,
    borderRadius: theme.radius.md,
    padding: theme.spacing.md,
    color: theme.colors.text.primary,
    fontSize: theme.font.sizes.md,
    borderWidth: 1, borderColor: theme.colors.bg.border,
  },
  textarea: { minHeight: 120, textAlignVertical: "top" },
  generateBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: theme.spacing.sm,
    backgroundColor: theme.colors.accent.cyan,
    borderRadius: theme.radius.full,
    padding: theme.spacing.md,
    marginTop: theme.spacing.sm,
  },
  generateBtnDisabled: { opacity: 0.6 },
  generateBtnText: { color: theme.colors.bg.primary, fontWeight: theme.font.weights.bold, fontSize: theme.font.sizes.md },
  resultContainer: {
    margin: theme.spacing.md,
    backgroundColor: theme.colors.bg.card,
    borderRadius: theme.radius.lg,
    padding: theme.spacing.md,
    borderWidth: 1, borderColor: theme.colors.bg.border,
  },
  resultHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: theme.spacing.md },
  resultTitle: { color: theme.colors.text.primary, fontWeight: theme.font.weights.semibold, fontSize: theme.font.sizes.md },
  resultActions: { flexDirection: "row", gap: theme.spacing.sm },
  actionBtn: { flexDirection: "row", alignItems: "center", gap: 4, padding: theme.spacing.xs },
  actionBtnText: { color: theme.colors.accent.cyan, fontSize: theme.font.sizes.sm },
  resultText: { color: theme.colors.text.secondary, fontSize: theme.font.sizes.sm, lineHeight: 22 },
  regenerateBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: theme.spacing.xs,
    marginTop: theme.spacing.md, padding: theme.spacing.sm,
    borderTopWidth: 1, borderTopColor: theme.colors.bg.border,
  },
  regenerateBtnText: { color: theme.colors.text.secondary, fontSize: theme.font.sizes.sm },
});
